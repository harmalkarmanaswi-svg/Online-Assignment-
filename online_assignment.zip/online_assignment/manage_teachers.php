<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $teacher_row_id = (int)($_POST['teacher_row_id'] ?? 0);
    $new_password = trim($_POST['new_password'] ?? '');

    if ($teacher_row_id > 0 && $new_password !== '') {
        $hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE teachers SET password=? WHERE id=?");
        $stmt->bind_param("si", $hash, $teacher_row_id);
        $stmt->execute();
        $msg = "Teacher password updated.";
    }
}

$res = $conn->query("SELECT id, full_name, teacher_id, email, created_at FROM teachers ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Teachers</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif}
body{background:#f5f6fa}
.box{max-width:1150px;margin:40px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,.08)}
.msg{background:#e8fff0;color:#116530;padding:10px;border-radius:10px;margin-bottom:12px}
table{width:100%;border-collapse:collapse}
th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}
th{background:#111;color:#fff}
input{padding:10px;border:1px solid #ccc;border-radius:10px}
button,.btn{background:#111;color:#fff;border:none;padding:10px 14px;border-radius:10px;text-decoration:none}
</style>
</head>
<body>
<div class="box">
  <h2 style="margin-bottom:15px;">Manage Teachers</h2>

  <?php if($msg !== ""): ?>
    <div class="msg"><?php echo htmlspecialchars($msg); ?></div>
  <?php endif; ?>

  <table>
    <tr>
      <th>Name</th>
      <th>Teacher ID</th>
      <th>Email</th>
      <th>Created</th>
      <th>Reset Password</th>
    </tr>
    <?php while($row = $res->fetch_assoc()): ?>
    <tr>
      <td><?php echo htmlspecialchars($row['full_name']); ?></td>
      <td><?php echo htmlspecialchars($row['teacher_id']); ?></td>
      <td><?php echo htmlspecialchars($row['email']); ?></td>
      <td><?php echo htmlspecialchars($row['created_at']); ?></td>
      <td>
        <form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;">
          <input type="hidden" name="teacher_row_id" value="<?php echo (int)$row['id']; ?>">
          <input type="text" name="new_password" placeholder="New Password" required>
          <button type="submit" name="reset_password">Update</button>
        </form>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>

  <br>
  <a class="btn" href="admin_dashboard.php">Back</a>
</div>
</body>
</html>