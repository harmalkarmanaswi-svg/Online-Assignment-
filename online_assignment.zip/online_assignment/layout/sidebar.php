<div class="sidebar">

<a href="student_dashboard.php">Dashboard</a>

<a href="student_assignments.php">Assignments</a>

<a href="student_results.php">Results</a>

<a href="logout.php">Logout</a>

</div>