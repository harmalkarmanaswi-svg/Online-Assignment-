<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>

<title>Assignment System</title>

<link rel="stylesheet" href="assets/style.css">

</head>
<body>

<div class="topbar">

Online Assignment Submission System

</div>