<div class="sidebar">

<a href="teacher_dashboard.php">Dashboard</a>

<a href="create_assignment.php">Create Assignment</a>

<a href="manage_assignments.php">Manage Assignment</a>

<a href="view_submissions.php">Submissions</a>

<a href="logout.php">Logout</a>

</div>
