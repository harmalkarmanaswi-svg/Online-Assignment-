<?php
session_start();
require_once("../config/db.php");

$msg = "";

if(isset($_POST['login'])){

    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM admins WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 1){

        $row = $result->fetch_assoc();

        if(password_verify($pass, $row['password'])){

            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_name'] = $row['full_name'];

            header("Location: ../admin/dashboard.php");
            exit();

        } else {
            $msg = "Wrong Password";
        }

    } else {
        $msg = "Admin not found";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
</head>
<body>

<h2>Admin Login</h2>

<form method="POST">
Email<br>
<input type="email" name="email" required><br><br>

Password<br>
<input type="password" name="password" required><br><br>

<button type="submit" name="login">Login</button>
</form>

<p><?php echo $msg; ?></p>

</body>
</html>