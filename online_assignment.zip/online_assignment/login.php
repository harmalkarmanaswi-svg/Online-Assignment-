<?php
session_start();
require_once(__DIR__ . "/config/db.php");

$msg = "";
$success = "";

if (isset($_GET['registered'])) {
    $success = "Registration successful. Please login.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'] ?? '';
    $login_id = trim($_POST['login_id'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($role === "" || $login_id === "" || $password === "") {
        $msg = "Please fill all fields.";
    } else {

        if ($role === "student") {

            if (!preg_match('/^\d{16}$/', $login_id)) {
                $msg = "Student PRN must be exactly 16 digits.";
            } else {
                $stmt = $conn->prepare(
                    "SELECT id, full_name, prn, password
                     FROM students
                     WHERE prn = ? LIMIT 1"
                );

                $stmt->bind_param("s", $login_id);
                $stmt->execute();
                $res = $stmt->get_result();

                if ($res->num_rows === 1) {
                    $row = $res->fetch_assoc();

                    if (password_verify($password, $row['password'])) {
                        $_SESSION['student_id'] = $row['id'];
                        $_SESSION['student_name'] = $row['full_name'];
                        $_SESSION['student_prn'] = $row['prn'];

                        header("Location: student_dashboard.php");
                        exit();
                    } else {
                        $msg = "Wrong password.";
                    }
                } else {
                    $msg = "Student not found.";
                }
            }

        } elseif ($role === "teacher") {

            if (!preg_match('/^\d{8}$/', $login_id)) {
                $msg = "Teacher ID must be exactly 8 digits.";
            } else {
                $stmt = $conn->prepare(
                    "SELECT id, full_name, teacher_id, password
                     FROM teachers
                     WHERE teacher_id = ? LIMIT 1"
                );

                $stmt->bind_param("s", $login_id);
                $stmt->execute();
                $res = $stmt->get_result();

                if ($res->num_rows === 1) {
                    $row = $res->fetch_assoc();

                    if (password_verify($password, $row['password'])) {
                        $_SESSION['teacher_id'] = $row['id'];
                        $_SESSION['teacher_name'] = $row['full_name'];
                        $_SESSION['teacher_code'] = $row['teacher_id'];

                        header("Location: teacher_dashboard.php");
                        exit();
                    } else {
                        $msg = "Wrong password.";
                    }
                } else {
                    $msg = "Teacher not found.";
                }
            }

        } else {
            $msg = "Please select a valid role.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:Arial, sans-serif;
}

body{
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
  padding:20px;
}

.card{
  width:100%;
  max-width:450px;
  background:#ffffff;
  padding:30px;
  border-radius:18px;
  box-shadow:0 20px 45px rgba(0,0,0,0.18);
}

h2{
  margin-bottom:18px;
  color:#111;
}

.field{
  margin-bottom:15px;
}

input, select{
  width:100%;
  padding:14px 12px;
  border:1px solid #ccc;
  border-radius:10px;
  font-size:15px;
  outline:none;
}

input:focus, select:focus{
  border-color:#203a43;
  box-shadow:0 0 0 3px rgba(32,58,67,0.10);
}

.password-wrap{
  position:relative;
  width:100%;
}

.password-wrap input{
  width:100%;
  padding:14px 90px 14px 12px;
  border:1px solid #ccc;
  border-radius:10px;
  font-size:15px;
  outline:none;
}

.password-wrap input:focus{
  border-color:#203a43;
  box-shadow:0 0 0 3px rgba(32,58,67,0.10);
}

.toggle-btn{
  position:absolute;
  right:8px;
  top:50%;
  transform:translateY(-50%);
  border:none;
  background:#203a43;
  color:#fff;
  padding:8px 12px;
  border-radius:8px;
  cursor:pointer;
  font-size:12px;
  font-weight:bold;
}

.toggle-btn:hover{
  background:#162a31;
}

.btn{
  width:100%;
  padding:13px;
  background:#203a43;
  color:white;
  border:none;
  border-radius:10px;
  font-size:15px;
  font-weight:bold;
  cursor:pointer;
}

.btn:hover{
  background:#162a31;
}

.msg{
  padding:10px;
  margin-bottom:12px;
  border-radius:10px;
  font-size:14px;
}

.error{
  background:#ffe5e5;
  color:#b00020;
}

.success{
  background:#e8fff0;
  color:#116530;
}

.bottom{
  margin-top:16px;
  text-align:center;
  font-size:14px;
}

.bottom a{
  color:#203a43;
  text-decoration:none;
  font-weight:bold;
}
</style>
</head>
<body>

<div class="card">
  <h2>Login</h2>

  <?php if($success != ""): ?>
    <div class="msg success"><?php echo htmlspecialchars($success); ?></div>
  <?php endif; ?>

  <?php if($msg != ""): ?>
    <div class="msg error"><?php echo htmlspecialchars($msg); ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="field">
      <select name="role" id="roleSelect" required>
        <option value="">Select Role</option>
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
      </select>
    </div>

    <div class="field">
      <input type="text" name="login_id" id="login_id" placeholder="PRN / Teacher ID" required>
    </div>

    <div class="field">
      <div class="password-wrap">
        <input type="password" name="password" id="password" placeholder="Password" required>
        <button type="button" class="toggle-btn" onclick="togglePassword()" id="toggleBtn">Show</button>
      </div>
    </div>

    <button type="submit" class="btn">Login</button>
  </form>

  <div class="bottom">
    Don’t have an account? <a href="register.php">Register</a>
  </div>
</div>

<script>
function togglePassword() {
  var x = document.getElementById("password");
  var btn = document.getElementById("toggleBtn");

  if (x.type === "password") {
    x.type = "text";
    btn.textContent = "Hide";
  } else {
    x.type = "password";
    btn.textContent = "Show";
  }
}

const roleSelect = document.getElementById('roleSelect');
const loginInput = document.getElementById('login_id');

function updateLoginField() {
  if (roleSelect.value === "student") {
    loginInput.placeholder = "Enter 16-digit PRN";
    loginInput.maxLength = 16;
  } else if (roleSelect.value === "teacher") {
    loginInput.placeholder = "Enter 8-digit Teacher ID";
    loginInput.maxLength = 8;
  } else {
    loginInput.placeholder = "PRN / Teacher ID";
    loginInput.maxLength = 20;
  }
}

roleSelect.addEventListener('change', updateLoginField);
updateLoginField();
</script>

</body>
</html>