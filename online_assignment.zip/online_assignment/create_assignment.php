<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: login.php");
    exit();
}

require_once(__DIR__ . "/config/db.php");

$msg = "";

// ✅ teacher subject from session
$default_subject = $_SESSION['teacher_subject'] ?? "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $due_date = $_POST['due_date'] ?? '';
    $subject = trim($_POST['subject'] ?? ''); // from input field
    $teacher_id = $_SESSION['teacher_id'];

    if ($title === '' || $due_date === '' || $subject === '') {
        $msg = "Title, subject and due date are required.";
    } else {

        // ✅ INSERT QUERY
        $stmt = $conn->prepare("INSERT INTO assignments(title, description, due_date, subject, teacher_id) VALUES(?,?,?,?,?)");
        $stmt->bind_param(
            "ssssi",
            $title,
            $description,
            $due_date,
            $subject,
            $teacher_id
        );
        $stmt->execute();

        $msg = "Assignment created successfully.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Assignment</title>
<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
body{background:#eef8f5}
.box{
max-width:700px;
margin:50px auto;
background:#fff;
padding:30px;
border-radius:20px;
box-shadow:0 15px 40px rgba(0,0,0,.08)
}
h2{color:#11998e;margin-bottom:15px}
input,textarea{
width:100%;
padding:12px;
margin:8px 0;
border:1px solid #ccc;
border-radius:10px
}
textarea{height:120px;resize:vertical}
button,.btn{
background:#11998e;
color:#fff;
border:none;
padding:12px 18px;
border-radius:10px;
font-weight:bold;
text-decoration:none;
display:inline-block
}
.msg{
background:#e8fff0;
color:#116530;
padding:10px;
border-radius:10px;
margin-bottom:10px
}
</style>
</head>
<body>

<div class="box">

<h2>Create Assignment</h2>

<?php if($msg !== ""): ?>
<div class="msg">
<?php echo htmlspecialchars($msg); ?>
</div>
<?php endif; ?>

<form method="POST">

<!-- ✅ SUBJECT INPUT pre-filled with teacher's subject -->
<input type="text" name="subject" placeholder="Enter Subject" value="<?php echo htmlspecialchars($default_subject); ?>" required>

<input type="text" name="title" placeholder="Assignment Title" required>

<textarea name="description" placeholder="Assignment Description"></textarea>

<input type="date" name="due_date" required>

<button type="submit">Create Assignment</button>

</form>

<br>

<a class="btn" href="teacher_dashboard.php">Back</a>

</div>

</body>
</html>