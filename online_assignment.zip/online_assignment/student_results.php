<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$student_id = $_SESSION['student_id'];

$sql = "SELECT s.id, s.file_name, s.submitted_at, s.marks, s.teacher_remark,
               a.title, a.due_date
        FROM submissions s
        JOIN assignments a ON s.assignment_id = a.id
        WHERE s.student_id = ?
        ORDER BY s.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Results</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
    body{background:#f4f7fb}
    .box{max-width:1150px;margin:40px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 15px 40px rgba(0,0,0,.08)}
    h2{color:#1e3c72;margin-bottom:20px}
    table{width:100%;border-collapse:collapse}
    th,td{padding:13px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}
    th{background:#1e3c72;color:#fff}
    .btn{display:inline-block;background:#1e3c72;color:#fff;text-decoration:none;padding:10px 14px;border-radius:10px}
    .pending{color:#c62828;font-weight:bold}
    .empty{padding:20px;background:#f8f8f8;border-radius:12px;color:#666}
  </style>
</head>
<body>
  <div class="box">
    <h2>My Results</h2>

    <?php if($res->num_rows === 0): ?>
      <div class="empty">You have not submitted any assignment yet.</div>
    <?php else: ?>
      <table>
        <tr>
          <th>Assignment</th>
          <th>Due Date</th>
          <th>Submitted At</th>
          <th>File</th>
          <th>Marks</th>
          <th>Teacher Remark</th>
        </tr>

        <?php while($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['title']); ?></td>
          <td><?php echo htmlspecialchars($row['due_date']); ?></td>
          <td><?php echo htmlspecialchars($row['submitted_at']); ?></td>
          <td>
            <a href="uploads/<?php echo rawurlencode($row['file_name']); ?>" target="_blank">
              <?php echo htmlspecialchars($row['file_name']); ?>
            </a>
          </td>
          <td>
            <?php
              echo $row['marks'] !== null
                ? (int)$row['marks'] . " / 100"
                : '<span class="pending">Pending</span>';
            ?>
          </td>
          <td>
            <?php
              echo !empty($row['teacher_remark'])
                ? htmlspecialchars($row['teacher_remark'])
                : 'No remark';
            ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </table>
    <?php endif; ?>

    <br>
    <a class="btn" href="student_dashboard.php">Back</a>
  </div>
</body>
</html>