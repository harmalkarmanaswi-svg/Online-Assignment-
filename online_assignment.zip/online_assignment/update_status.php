require_once("config/db.php");

$id = $_POST['id'];
$status = $_POST['status'];

$conn->query("UPDATE submissions SET status='$status' WHERE id='$id'");

header("Location: admin_dashboard.php");