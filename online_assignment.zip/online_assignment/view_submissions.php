<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$teacher_id = $_SESSION['teacher_id'];

$sql = "SELECT s.id, s.file_name, s.submitted_at, s.marks, s.teacher_remark,
               a.title, a.due_date,
               st.full_name AS student_name, st.prn
        FROM submissions s
        JOIN assignments a ON s.assignment_id = a.id
        JOIN students st ON s.student_id = st.id
        WHERE a.teacher_id = ?
        ORDER BY s.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Submissions</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
    body{background:#eef8f5}
    .box{max-width:1200px;margin:40px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 15px 40px rgba(0,0,0,.08)}
    h2{color:#11998e;margin-bottom:20px}
    table{width:100%;border-collapse:collapse}
    th,td{padding:13px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}
    th{background:#11998e;color:#fff}
    .btn{display:inline-block;background:#11998e;color:#fff;text-decoration:none;padding:10px 12px;border-radius:10px}
    .muted{color:#777}
    .empty{padding:20px;background:#f8f8f8;border-radius:12px;color:#666}
  </style>
</head>
<body>
  <div class="box">
    <h2>Student Submissions</h2>

    <?php if($res->num_rows === 0): ?>
      <div class="empty">No submissions found yet.</div>
    <?php else: ?>
      <table>
        <tr>
          <th>Student</th>
          <th>PRN</th>
          <th>Assignment</th>
          <th>Due Date</th>
          <th>File</th>
          <th>Submitted At</th>
          <th>Marks</th>
          <th>Remark</th>
          <th>Action</th>
        </tr>

        <?php while($row = $res->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['student_name']); ?></td>
          <td><?php echo htmlspecialchars($row['prn']); ?></td>
          <td><?php echo htmlspecialchars($row['title']); ?></td>
          <td><?php echo htmlspecialchars($row['due_date']); ?></td>
          <td>
            <a href="uploads/<?php echo rawurlencode($row['file_name']); ?>" target="_blank">
              <?php echo htmlspecialchars($row['file_name']); ?>
            </a>
          </td>
          <td><?php echo htmlspecialchars($row['submitted_at']); ?></td>
          <td><?php echo $row['marks'] !== null ? (int)$row['marks'] : '<span class="muted">Not Given</span>'; ?></td>
          <td><?php echo $row['teacher_remark'] ? htmlspecialchars($row['teacher_remark']) : '<span class="muted">No Remark</span>'; ?></td>
          <td>
            <a class="btn" href="give_marks.php?submission_id=<?php echo (int)$row['id']; ?>">Give Marks</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </table>
    <?php endif; ?>

    <br>
    <a class="btn" href="teacher_dashboard.php">Back</a>
  </div>
</body>
</html>