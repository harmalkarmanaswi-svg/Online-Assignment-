<?php
session_start();
require_once(__DIR__ . "/config/db.php");
$msg = "";

// Fetch subjects dynamically from teachers table
$subjects_result = $conn->query("SELECT DISTINCT subject FROM teachers ORDER BY subject ASC");
$subjects = [];
while($row = $subjects_result->fetch_assoc()){
    $subjects[] = $row['subject'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? "");
    $password = $_POST['password'] ?? "";
    $subject = trim($_POST['subject'] ?? "");

    if ($email === "" || $password === "" || $subject === "") {
        $msg = "Please fill all fields.";
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, password, subject FROM teachers WHERE email=? AND subject=? LIMIT 1");
        $stmt->bind_param("ss", $email, $subject);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 1) {
            $row = $res->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $_SESSION['teacher_id'] = $row['id'];
                $_SESSION['teacher_name'] = $row['full_name'];
                $_SESSION['teacher_subject'] = $row['subject'];
                header("Location: teacher_dashboard.php");
                exit();
            } else {
                $msg = "Wrong password.";
            }
        } else {
            $msg = "Teacher not found for this email and subject.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Teacher Login</title>
  <style>
    body{font-family:Arial;background:linear-gradient(135deg,#11998e,#38ef7d);display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
    .card{background:#fff;padding:30px;border-radius:18px;width:380px;box-shadow:0 20px 45px rgba(0,0,0,.2);}
    h2{text-align:center;color:#11998e;}
    input,select{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:10px;}
    button{width:100%;padding:12px;background:#11998e;color:#fff;border:none;border-radius:10px;font-weight:bold;}
    .ok{background:#e8fff0;color:#116530;padding:10px;border-radius:10px;margin-bottom:10px;}
    .msg{background:#ffe5e5;color:#b00020;padding:10px;border-radius:10px;margin-bottom:10px;}
  </style>
</head>
<body>
  <div class="card">
    <h2>Teacher Login</h2>

    <?php if(isset($_GET['registered'])): ?>
      <div class="ok">Registration successful. Please login.</div>
    <?php endif; ?>

    <?php if($msg!=""): ?><div class="msg"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

    <form method="POST">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>

      <!-- ✅ Subject Dropdown -->
      <select name="subject" required>
        <option value="">Select Subject</option>
        <?php foreach($subjects as $sub): ?>
          <option value="<?php echo htmlspecialchars($sub); ?>"><?php echo htmlspecialchars($sub); ?></option>
        <?php endforeach; ?>
      </select>

      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>