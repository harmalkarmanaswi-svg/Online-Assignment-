<!DOCTYPE html>
<html>
<head>
<title>Student Register</title>
<style>

body{
font-family:Arial;
background:linear-gradient(135deg,#1e3c72,#2a5298);
height:100vh;
display:flex;
justify-content:center;
align-items:center;
color:white;
}

.card{
background:white;
color:black;
padding:30px;
border-radius:10px;
width:350px;
text-align:center;
}

input{
width:100%;
padding:10px;
margin:8px 0;
}

button{
padding:10px;
width:100%;
background:#1e3c72;
color:white;
border:none;
}

a{color:blue;}

</style>
</head>
<body>

<div class="card">

<h2>Student Register</h2>

<form>

<input type="text" placeholder="Name">

<input type="email" placeholder="Email">

<input type="password" placeholder="Password">

<button>Register</button>

</form>

<br>

<a href="student_login.php">Login</a>

</div>

</body>
</html>