<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$teacher_id = $_SESSION['teacher_id'];
$teacher_name = $_SESSION['teacher_name'] ?? 'Teacher';
$teacher_code = $_SESSION['teacher_code'] ?? '';

$stmt1 = $conn->prepare("SELECT COUNT(*) AS c FROM assignments WHERE teacher_id=?");
$stmt1->bind_param("i", $teacher_id);
$stmt1->execute();
$totalAssignments = $stmt1->get_result()->fetch_assoc()['c'];

$stmt2 = $conn->prepare("SELECT COUNT(*) AS c
                         FROM submissions s
                         JOIN assignments a ON s.assignment_id = a.id
                         WHERE a.teacher_id=?");
$stmt2->bind_param("i", $teacher_id);
$stmt2->execute();
$totalSubmissions = $stmt2->get_result()->fetch_assoc()['c'];

$stmt3 = $conn->prepare("SELECT COUNT(*) AS c
                         FROM submissions s
                         JOIN assignments a ON s.assignment_id = a.id
                         WHERE a.teacher_id=? AND s.marks IS NOT NULL");
$stmt3->bind_param("i", $teacher_id);
$stmt3->execute();
$gradedCount = $stmt3->get_result()->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher Dashboard</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
    body{background:#eef8f5;margin:0}
    .topbar{
      background:#11998e;
      color:#fff;
      padding:18px 25px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      flex-wrap:wrap;
      gap:10px;
    }
    .topbar h1{font-size:24px}
    .user-box{
      background:rgba(255,255,255,.12);
      padding:10px 14px;
      border-radius:12px;
      font-size:14px;
      line-height:1.6;
    }
    .wrap{padding:25px;max-width:1100px;margin:auto}
    .stats{
      display:grid;
      grid-template-columns:repeat(3,1fr);
      gap:20px;
      margin-bottom:25px;
    }
    .cards{
      display:grid;
      grid-template-columns:repeat(4,1fr);
      gap:20px;
    }
    .stat,.card{
      background:#fff;
      padding:25px;
      border-radius:18px;
      box-shadow:0 10px 30px rgba(0,0,0,.08);
    }
    .stat h3,.card h3{margin-bottom:10px;color:#11998e}
    .stat p{font-size:30px;font-weight:bold;color:#111}
    .card p{color:#555;line-height:1.6;margin-bottom:16px}
    .btn{
      display:inline-block;
      text-decoration:none;
      background:#11998e;
      color:#fff;
      padding:12px 18px;
      border-radius:10px;
      font-weight:bold;
    }
    .btn.logout{background:#c62828}
    @media(max-width:900px){
      .stats,.cards{grid-template-columns:1fr}
      .topbar{flex-direction:column;align-items:flex-start}
    }
  </style>
</head>
<body>
  <div class="topbar">
    <h1>Teacher Dashboard</h1>
    <div class="user-box">
      <div><strong>Name:</strong> <?php echo htmlspecialchars($teacher_name); ?></div>
      <div><strong>Teacher ID:</strong> <?php echo htmlspecialchars($teacher_code); ?></div>
    </div>
  </div>

  <div class="wrap">
    <div class="stats">
      <div class="stat">
        <h3>Total Assignments</h3>
        <p><?php echo (int)$totalAssignments; ?></p>
      </div>
      <div class="stat">
        <h3>Total Submissions</h3>
        <p><?php echo (int)$totalSubmissions; ?></p>
      </div>
      <div class="stat">
        <h3>Graded</h3>
        <p><?php echo (int)$gradedCount; ?></p>
      </div>
    </div>

    <div class="cards">
      <div class="card">
        <h3>Create Assignment</h3>
        <p>Create assignments with title, details and due date.</p>
        <a class="btn" href="create_assignment.php">Create</a>
      </div>

      <div class="card">
        <h3>Manage Assignments</h3>
        <p>Edit or delete your created assignments.</p>
        <a class="btn" href="manage_assignments.php">Manage</a>
      </div>

      <div class="card">
        <h3>View Submissions</h3>
        <p>Check uploaded files and give marks.</p>
        <a class="btn" href="view_submissions.php">Open</a>
      </div>

      <div class="card">
        <h3>Logout</h3>
        <p>Sign out safely from your account.</p>
        <a class="btn logout" href="logout.php">Logout</a>
      </div>
    </div>
  </div>
</body>
</html>