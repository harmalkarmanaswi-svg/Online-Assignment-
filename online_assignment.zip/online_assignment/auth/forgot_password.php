<form method="POST">
<input type="email" name="email" placeholder="Enter email">
<button>Send Reset Link</button>
</form>