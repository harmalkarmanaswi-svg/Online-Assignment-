$new = password_hash($_POST['password'], PASSWORD_DEFAULT);

$email = $_SESSION['reset_email'];

$conn->query("UPDATE students SET password='$new' WHERE email='$email'");