<?php
session_start();
require_once("../config/db.php");

$msg = "";

if(isset($_POST['register'])){
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM admins WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0){
        $msg = "Email already registered! Please use another email.";
    } else {
        // Hash password securely
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO admins (full_name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $full_name, $email, $hashed_password);

        if($stmt->execute()){
            // Get the inserted admin ID
            $admin_id = $stmt->insert_id;

            // Set session to log in admin automatically
            $_SESSION['admin_id'] = $admin_id;
            $_SESSION['admin_name'] = $full_name;

            // Redirect to dashboard
            header("Location: ../admin/dashboard.php");
            exit();
        } else {
            $msg = "Error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register Admin</title>
<style>
body {
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #111, #444);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
  color: #fff;
}
.card {
  background: #fff;
  color: #111;
  padding: 30px;
  border-radius: 18px;
  width: 360px;
  text-align: center;
  box-shadow: 0 0 15px rgba(0,0,0,0.3);
}
input {
  width: 100%;
  padding: 12px;
  margin: 8px 0;
  border: 1px solid #ccc;
  border-radius: 10px;
  font-size: 16px;
}
button {
  width: 100%;
  padding: 12px;
  background: #111;
  color: #fff;
  border: none;
  border-radius: 10px;
  font-weight: bold;
  font-size: 16px;
  cursor: pointer;
}
button:hover {
  background: #333;
}
.message {
  margin-top: 15px;
  font-weight: bold;
  color: green;
}
.error {
  margin-top: 15px;
  font-weight: bold;
  color: red;
}
</style>
</head>
<body>

<div class="card">
  <h2>Register Admin</h2>
  <form method="POST">
    <input type="text" name="full_name" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" name="register">Register</button>
  </form>

  <?php if ($msg): ?>
    <div class="<?php echo strpos($msg, 'Error') === false ? 'message' : 'error'; ?>">
      <?php echo htmlspecialchars($msg); ?>
    </div>
  <?php endif; ?>
</div>

</body>
</html>