<?php
session_start();
require_once(__DIR__ . "/config/db.php");
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['full_name'] ?? "");
    $email = trim($_POST['email'] ?? "");
    $prn = trim($_POST['prn'] ?? "");   // ✅ NEW
    $password = $_POST['password'] ?? "";

    if ($name === "" || $email === "" || $prn === "" || $password === "") {
        $msg = "Please fill all fields.";
    } else {
        $check = $conn->prepare("SELECT id FROM students WHERE full_name=? OR email=? OR prn=? LIMIT 1");
$check->bind_param("sss", $name, $email, $prn);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $msg = "Email already exists.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // ✅ UPDATED INSERT
            $stmt = $conn->prepare("INSERT INTO students(full_name,email,prn,password) VALUES(?,?,?,?)");
            $stmt->bind_param("ssss", $name, $email, $prn, $hash);

            $stmt->execute();

            header("Location: student_login.php?registered=1");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Register</title>
  <style>
    body{font-family:Arial;background:linear-gradient(135deg,#1e3c72,#2a5298);display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
    .card{background:#fff;padding:30px;border-radius:18px;width:380px;box-shadow:0 20px 45px rgba(0,0,0,.2);}
    h2{text-align:center;color:#1e3c72;}
    input{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:10px;}
    button{width:100%;padding:12px;background:#1e3c72;color:#fff;border:none;border-radius:10px;font-weight:bold;}
    .msg{background:#ffe5e5;color:#b00020;padding:10px;border-radius:10px;margin-bottom:10px;}
    a{color:#1e3c72;text-decoration:none;}
    p{text-align:center;}
  </style>
</head>
<body>
  <div class="card">
    <h2>Student Register</h2>

    <?php if($msg!=""): ?>
      <div class="msg"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <form method="POST">
      <input type="text" name="full_name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>

      <!-- ✅ NEW FIELD -->
      <input type="text" name="prn" placeholder="PRN Number" required>

      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Register</button>
    </form>

    <p>Already have account? <a href="student_login.php">Login</a></p>
  </div>
</body>
</html>