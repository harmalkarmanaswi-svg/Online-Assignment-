<?php
session_start();
require_once("../config/db.php");

$msg = "";

if(isset($_POST['login'])){
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Get admin record by email
    $stmt = $conn->prepare("SELECT * FROM admins WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 1){
        $row = $result->fetch_assoc();

        // Verify password
        if(password_verify($password, $row['password'])){
            // Set session
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_name'] = $row['full_name'];

            // Redirect to dashboard
            header("Location: ../admin/dashboard.php");
            exit();
        } else {
            $msg = "Wrong Password";
        }
    } else {
        $msg = "Admin not found";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<style>
body {
  font-family: Arial, sans-serif;
  background: linear-gradient(135deg, #111, #444);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
  color: #fff;
}
.card {
  background: #fff;
  color: #111;
  padding: 30px;
  border-radius: 18px;
  width: 360px;
  text-align: center;
  box-shadow: 0 0 15px rgba(0,0,0,0.3);
}
input {
  width: 100%;
  padding: 12px;
  margin: 8px 0;
  border: 1px solid #ccc;
  border-radius: 10px;
  font-size: 16px;
}
button {
  width: 100%;
  padding: 12px;
  background: #111;
  color: #fff;
  border: none;
  border-radius: 10px;
  font-weight: bold;
  font-size: 16px;
  cursor: pointer;
}
button:hover {
  background: #333;
}
.error {
  margin-top: 15px;
  font-weight: bold;
  color: red;
}
</style>
</head>
<body>

<div class="card">
  <h2>Admin Login</h2>
  <form method="POST">
    <input type="email" name="email" placeholder="Admin Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" name="login">Login</button>
  </form>

  <?php if ($msg): ?>
    <div class="error"><?php echo htmlspecialchars($msg); ?></div>
  <?php endif; ?>
</div>

</body>
</html>