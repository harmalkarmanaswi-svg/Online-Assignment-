<?php
require_once("../config/db.php");

$msg = "";

if(isset($_POST['register'])){

    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);

    if($name=="" || $email=="" || $pass==""){
        $msg = "All fields required";
    } else {

        // check email exist
        $check = $conn->prepare("SELECT id FROM admins WHERE email=?");
        $check->bind_param("s",$email);
        $check->execute();
        $res = $check->get_result();

        if($res->num_rows > 0){
            $msg = "Email already exists";
        } else {

            $hash = password_hash($pass, PASSWORD_DEFAULT);

            $stmt = $conn->prepare(
                "INSERT INTO admins(full_name,email,password) VALUES(?,?,?)"
            );

            $stmt->bind_param("sss",$name,$email,$hash);

            if($stmt->execute()){
                $msg = "Admin Registered Successfully";
            } else {
                $msg = "Error occurred";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Register</title>
</head>
<body>

<h2>Admin Register</h2>

<form method="POST">

Name<br>
<input type="text" name="name"><br><br>

Email<br>
<input type="email" name="email"><br><br>

Password<br>
<input type="password" name="password"><br><br>

<button name="register">Register</button>

</form>

<p><?php echo $msg; ?></p>

<a href="admin_login.php">Go to Login</a>

</body>
</html>