<?php
session_start();
require_once(__DIR__ . "/config/db.php");
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? "");
    $password = $_POST['password'] ?? "";

    $stmt = $conn->prepare("SELECT id, full_name, password FROM students WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $row = $res->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['student_id'] = $row['id'];
            $_SESSION['student_name'] = $row['full_name'];
            header("Location: student_dashboard.php");
            exit();
        } else {
            $msg = "Wrong password.";
        }
    } else {
        $msg = "Student not found.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Login</title>
  <style>
    body{font-family:Arial;background:linear-gradient(135deg,#1e3c72,#2a5298);display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
    .card{background:#fff;padding:30px;border-radius:18px;width:380px;box-shadow:0 20px 45px rgba(0,0,0,.2);}
    h2{text-align:center;color:#1e3c72;}
    input{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:10px;}
    button{width:100%;padding:12px;background:#1e3c72;color:#fff;border:none;border-radius:10px;font-weight:bold;}
    .ok{background:#e8fff0;color:#116530;padding:10px;border-radius:10px;margin-bottom:10px;}
    .msg{background:#ffe5e5;color:#b00020;padding:10px;border-radius:10px;margin-bottom:10px;}
  </style>
</head>
<body>
  <div class="card">
    <h2>Student Login</h2>

    <?php if(isset($_GET['registered'])): ?>
      <div class="ok">Registration successful. Please login.</div>
    <?php endif; ?>

    <?php if($msg!=""): ?><div class="msg"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

    <form method="POST">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>