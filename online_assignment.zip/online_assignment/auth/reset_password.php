if($_SERVER['REQUEST_METHOD']=='POST'){
$email = $_POST['email'];

$res = $conn->query("SELECT * FROM students WHERE email='$email'");

if($res->num_rows > 0){
    $_SESSION['reset_email'] = $email;
    header("Location: new_password.php");
}
}