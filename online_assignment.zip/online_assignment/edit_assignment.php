<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$id = (int)($_GET['id'] ?? 0);
$teacher_id = $_SESSION['teacher_id'];
$msg = "";

$stmt = $conn->prepare("SELECT * FROM assignments WHERE id=? AND teacher_id=? LIMIT 1");
$stmt->bind_param("ii", $id, $teacher_id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

if (!$data) {
    die("Assignment not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? "");
    $description = trim($_POST['description'] ?? "");
    $due_date = $_POST['due_date'] ?? "";

    if ($title === "" || $due_date === "") {
        $msg = "Title and due date are required.";
    } else {
        $up = $conn->prepare("UPDATE assignments SET title=?, description=?, due_date=? WHERE id=? AND teacher_id=?");
        $up->bind_param("sssii", $title, $description, $due_date, $id, $teacher_id);
        $up->execute();
        $msg = "Assignment updated successfully.";

        $stmt = $conn->prepare("SELECT * FROM assignments WHERE id=? AND teacher_id=? LIMIT 1");
        $stmt->bind_param("ii", $id, $teacher_id);
        $stmt->execute();
        $data = $stmt->get_result()->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Assignment</title>
  <style>
    body{font-family:Arial;background:#eef8f5;margin:0;}
    .box{max-width:700px;margin:50px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 15px 40px rgba(0,0,0,.08);}
    h2{color:#11998e;margin-bottom:15px;}
    input,textarea{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:10px;}
    textarea{height:120px;resize:vertical;}
    button,.btn{background:#11998e;color:#fff;border:none;padding:12px 18px;border-radius:10px;font-weight:bold;text-decoration:none;display:inline-block;}
    .msg{background:#e8fff0;color:#116530;padding:10px;border-radius:10px;margin-bottom:10px;}
  </style>
</head>
<body>
  <div class="box">
    <h2>Edit Assignment</h2>

    <?php if($msg!=""): ?><div class="msg"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

    <form method="POST">
      <input type="text" name="title" value="<?php echo htmlspecialchars($data['title']); ?>" required>
      <textarea name="description"><?php echo htmlspecialchars($data['description']); ?></textarea>
      <input type="date" name="due_date" value="<?php echo htmlspecialchars($data['due_date']); ?>" required>
      <button type="submit">Update Assignment</button>
    </form>

    <br>
    <a class="btn" href="manage_assignments.php">Back</a>
  </div>
</body>
</html>