<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$teacher_id = $_SESSION['teacher_id'];

$stmt = $conn->prepare("SELECT id, title, description, due_date, created_at FROM assignments WHERE teacher_id=? ORDER BY id DESC");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Assignments</title>
  <style>
    body{font-family:Arial;background:#eef8f5;margin:0;}
    .box{max-width:1100px;margin:40px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 15px 40px rgba(0,0,0,.08);}
    h2{color:#11998e;margin-bottom:20px;}
    table{width:100%;border-collapse:collapse;}
    th,td{padding:13px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top;}
    th{background:#11998e;color:#fff;}
    .btn{display:inline-block;background:#11998e;color:#fff;text-decoration:none;padding:9px 12px;border-radius:10px;margin-right:6px;}
    .btn.del{background:#c62828;}
  </style>
</head>
<body>
  <div class="box">
    <h2>Manage Assignments</h2>

    <table>
      <tr>
        <th>Title</th>
        <th>Description</th>
        <th>Due Date</th>
        <th>Created</th>
        <th>Action</th>
      </tr>

      <?php while($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($row['title']); ?></td>
        <td><?php echo nl2br(htmlspecialchars($row['description'])); ?></td>
        <td><?php echo htmlspecialchars($row['due_date']); ?></td>
        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
        
        <td>
          <a class="btn" href="edit_assignment.php?id=<?php echo $row['id']; ?>">Edit</a>
          <a class="btn del" href="delete_assignment.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this assignment?')">Delete</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>

    <br>
    <a class="btn" href="teacher_dashboard.php">Back</a>
  </div>
</body>
</html>