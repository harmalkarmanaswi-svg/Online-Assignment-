<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: teacher_login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$id = (int)($_GET['id'] ?? 0);
$teacher_id = $_SESSION['teacher_id'];

$stmt = $conn->prepare("DELETE FROM assignments WHERE id=? AND teacher_id=?");
$stmt->bind_param("ii", $id, $teacher_id);
$stmt->execute();

header("Location: manage_assignments.php");
exit();