<?php
session_start();
require_once("../config/db.php");

// 🔒 SECURITY CHECK (VERY IMPORTANT)
if (!isset($_SESSION['admin_id']) || empty($_SESSION['admin_id'])) {
    header("Location: ../auth/admin_login.php");
    exit();
}

// Counts
$studentCount = $conn->query("SELECT COUNT(*) AS c FROM students")->fetch_assoc()['c'] ?? 0;
$teacherCount = $conn->query("SELECT COUNT(*) AS c FROM teachers")->fetch_assoc()['c'] ?? 0;
$assignmentCount = $conn->query("SELECT COUNT(*) AS c FROM assignments")->fetch_assoc()['c'] ?? 0;
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<style>
body{font-family:Arial;background:#f5f6fa;margin:0}
.topbar{background:#111;color:#fff;padding:15px;display:flex;justify-content:space-between}
.container{padding:20px}
.card{background:#fff;padding:20px;margin:10px 0;border-radius:10px}
</style>
</head>

<body>

<div class="topbar">
    <div>Admin Dashboard</div>
    <div>
        <?php echo $_SESSION['admin_name']; ?> |
        <a href="../logout.php" style="color:white;">Logout</a>
    </div>
</div>

<div class="container">

<div class="card">
<h3>Total Students</h3>
<p><?php echo $studentCount; ?></p>
</div>

<div class="card">
<h3>Total Teachers</h3>
<p><?php echo $teacherCount; ?></p>
</div>

<div class="card">
<h3>Total Assignments</h3>
<p><?php echo $assignmentCount; ?></p>
</div>

<a href="../index.php">Home</a>

</div>

</body>
</html>