<?php
session_start();
require_once("config/db.php");

$email = $_POST['email'] ?? "";
$password = $_POST['password'] ?? "";

if ($email && $password) {
    $stmt = $conn->prepare("SELECT id, full_name, password, session_id FROM students WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {

            // Check if another session is active
            if (!empty($row['session_id'])) {
                session_destroy();
                die("You are already logged in from another device/browser.");
            }

            // Login successful
            $_SESSION['student_id'] = $row['id'];
            $_SESSION['student_name'] = $row['full_name'];

            // Store current PHP session id in database
            $current_session_id = session_id();
            $stmt2 = $conn->prepare("UPDATE students SET session_id=? WHERE id=?");
            $stmt2->bind_param("si", $current_session_id, $row['id']);
            $stmt2->execute();

            header("Location: student_dashboard.php");
            exit();
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "User not found!";
    }
}
?><!DOCTYPE html>
<html>
<head>
<title>Student Login</title>
<style>

body{
font-family:Arial;
background:linear-gradient(135deg,#1e3c72,#2a5298);
height:100vh;
display:flex;
justify-content:center;
align-items:center;
color:white;
}

.card{
background:white;
color:black;
padding:30px;
border-radius:10px;
width:350px;
text-align:center;
}

input{
width:100%;
padding:10px;
margin:8px 0;
}

button{
padding:10px;
width:100%;
background:#1e3c72;
color:white;
border:none;
}

</style>
</head>
<body>

<div class="card">

<h2>Student Login</h2>

<form>

<input type="email" placeholder="Email">

<input type="password" placeholder="Password">

<button>Login</button>

</form>

</div>

</body>
</html>