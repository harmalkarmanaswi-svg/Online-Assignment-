<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$sql = "SELECT a.id, a.title, a.description, a.due_date, t.full_name AS teacher_name
        FROM assignments a
        JOIN teachers t ON a.teacher_id = t.id
        ORDER BY a.id DESC";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Assignments</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
    body{background:#f4f7fb}
    .box{max-width:1100px;margin:40px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 15px 40px rgba(0,0,0,.08)}
    h2{color:#1e3c72;margin-bottom:20px}
    table{width:100%;border-collapse:collapse}
    th,td{padding:14px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}
    th{background:#1e3c72;color:#fff}
    .btn{display:inline-block;background:#1e3c72;color:#fff;text-decoration:none;padding:10px 14px;border-radius:10px}
  </style>
</head>
<body>
  <div class="box">
    <h2>Available Assignments</h2>

    <table>
      <tr>
        <th>Title</th>
        <th>Description</th>
        <th>Teacher</th>
        <th>Due Date</th>
        <th>Action</th>
      </tr>

      <?php while($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($row['title']); ?></td>
        <td><?php echo nl2br(htmlspecialchars($row['description'])); ?></td>
        <td><?php echo htmlspecialchars($row['teacher_name']); ?></td>
        <td><?php echo htmlspecialchars($row['due_date']); ?></td>
        <td>
          <a class="btn" href="submit_assignment.php?assignment_id=<?php echo (int)$row['id']; ?>">Submit</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>

    <br>
    <a class="btn" href="student_dashboard.php">Back</a>
  </div>
</body>
</html>