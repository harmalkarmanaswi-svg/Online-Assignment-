<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Online Assignment Submission System</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif}
    body{
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      background:linear-gradient(135deg,#1e3c72,#2a5298,#4facfe);
      padding:20px;
      color:#fff;
    }
    .card{
      max-width:700px;
      width:100%;
      text-align:center;
      background:rgba(255,255,255,.12);
      padding:40px;
      border-radius:22px;
      backdrop-filter:blur(10px);
      border:1px solid rgba(255,255,255,.16);
    }
    h1{font-size:40px;margin-bottom:14px}
    p{font-size:18px;line-height:1.7;opacity:.92;margin-bottom:28px}
    .btns{
      display:flex;
      gap:14px;
      justify-content:center;
      flex-wrap:wrap;
    }
    .btn{
      display:inline-block;
      text-decoration:none;
      padding:14px 24px;
      border-radius:14px;
      font-weight:bold;
      background:#fff;
      color:#1e3c72;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Online Assignment Submission System</h1>
    <p>Students and teachers can login or register from one common portal by selecting their role.</p>
    <div class="btns">
      <a class="btn" href="register.php">Register</a>
      <a class="btn" href="login.php">Login</a>

  </div>
</body>
</html>