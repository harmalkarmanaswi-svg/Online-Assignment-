<?php
require_once("config/db.php");

// DELETE old admin first (avoid conflict)
$conn->query("DELETE FROM admins WHERE email='admin@gmail.com'");

$name = "Admin";
$email = "admin@gmail.com";
$password = password_hash("admin123", PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO admins(full_name,email,password) VALUES(?,?,?)");
$stmt->bind_param("sss",$name,$email,$password);

if($stmt->execute()){
    echo "✅ Admin created successfully <br>";
    echo "Email: admin@gmail.com <br>";
    echo "Password: admin123";
} else {
    echo "Error: " . $conn->error;
}
?>