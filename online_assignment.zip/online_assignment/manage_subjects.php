<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_name = trim($_POST['subject_name'] ?? '');
    $subject_code = trim($_POST['subject_code'] ?? '');

    if ($subject_name === '' || $subject_code === '') {
        $msg = "Please fill all fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO subjects (subject_name, subject_code) VALUES (?, ?)");
        $stmt->bind_param("ss", $subject_name, $subject_code);

        try {
            $stmt->execute();
            $msg = "Subject added successfully.";
        } catch (Exception $e) {
            $msg = "Subject name or code already exists.";
        }
    }
}

$res = $conn->query("SELECT * FROM subjects ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Subjects</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif}
body{background:#f5f6fa}
.box{max-width:1000px;margin:40px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,.08)}
h2{margin-bottom:18px}
.msg{background:#e8fff0;color:#116530;padding:10px;border-radius:10px;margin-bottom:12px}
input{width:100%;padding:12px;border:1px solid #ccc;border-radius:10px;margin-bottom:10px}
button,.btn{background:#111;color:#fff;border:none;padding:12px 16px;border-radius:10px;text-decoration:none;display:inline-block}
table{width:100%;border-collapse:collapse;margin-top:20px}
th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left}
th{background:#111;color:#fff}
</style>
</head>
<body>
<div class="box">
  <h2>Manage Subjects</h2>

  <?php if($msg !== ""): ?>
    <div class="msg"><?php echo htmlspecialchars($msg); ?></div>
  <?php endif; ?>

  <form method="POST">
    <input type="text" name="subject_name" placeholder="Subject Name" required>
    <input type="text" name="subject_code" placeholder="Subject Code" required>
    <button type="submit">Add Subject</button>
  </form>

  <table>
    <tr>
      <th>ID</th>
      <th>Subject Name</th>
      <th>Subject Code</th>
    </tr>
    <?php while($row = $res->fetch_assoc()): ?>
    <tr>
      <td><?php echo (int)$row['id']; ?></td>
      <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
      <td><?php echo htmlspecialchars($row['subject_code']); ?></td>
    </tr>
    <?php endwhile; ?>
  </table>

  <br>
  <a class="btn" href="admin_dashboard.php">Back</a>
</div>
</body>
</html>