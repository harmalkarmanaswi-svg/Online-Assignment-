<?php
session_start();
require_once(__DIR__ . "/config/db.php");
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['full_name'] ?? "");
    $email = trim($_POST['email'] ?? "");
    $prn = trim($_POST['prn'] ?? "");        // ✅ NEW
    $subject = trim($_POST['subject'] ?? "");
    $password = $_POST['password'] ?? "";

    if ($name === "" || $email === "" || $prn === "" || $subject === "" || $password === "") {
        $msg = "Please fill all fields.";
    } else {

        // ✅ CHECK duplicate email or PRN
        $check = $conn->prepare("SELECT id FROM teachers WHERE email=? OR prn=? LIMIT 1");
        $check->bind_param("ss", $email, $prn);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $msg = "Email or PRN already exists.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // ✅ FIXED INSERT
            $stmt = $conn->prepare("INSERT INTO teachers(full_name,email,prn,subject,password) VALUES(?,?,?,?,?)");
            $stmt->bind_param("sssss",$name,$email,$prn,$subject,$hash);

            $stmt->execute();

            header("Location: teacher_login.php?registered=1");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Teacher Register</title>
  <style>
    body{font-family:Arial;background:linear-gradient(135deg,#11998e,#38ef7d);display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
    .card{background:#fff;padding:30px;border-radius:18px;width:380px;box-shadow:0 20px 45px rgba(0,0,0,.2);}
    h2{text-align:center;color:#11998e;}
    input{width:100%;padding:12px;margin:8px 0;border:1px solid #ccc;border-radius:10px;}
    button{width:100%;padding:12px;background:#11998e;color:#fff;border:none;border-radius:10px;font-weight:bold;}
    .msg{background:#ffe5e5;color:#b00020;padding:10px;border-radius:10px;margin-bottom:10px;}
  </style>
</head>
<body>
  <div class="card">
    <h2>Teacher Register</h2>

    <?php if($msg!=""): ?>
      <div class="msg"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <form method="POST">
      <input type="text" name="full_name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>

      <!-- ✅ NEW PRN FIELD -->
      <input type="text" name="prn" placeholder="PRN Number" required>

      <!-- ✅ SUBJECT (teacher types) -->
      <input type="text" name="subject" placeholder="Subject" required>

      <input type="password" name="password" placeholder="Password" required>

      <button type="submit">Register</button>
    </form>
  </div>
</body>
</html>