<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$submission_id = (int)($_GET['submission_id'] ?? 0);
$msg = "";
$msgType = "ok";

$stmt = $conn->prepare("SELECT s.id, s.marks, s.teacher_remark, s.file_name,
                               a.title, a.due_date,
                               st.full_name AS student_name, st.prn
                        FROM submissions s
                        JOIN assignments a ON s.assignment_id = a.id
                        JOIN students st ON s.student_id = st.id
                        JOIN assignments ax ON s.assignment_id = ax.id
                        WHERE s.id = ? AND ax.teacher_id = ?
                        LIMIT 1");
$stmt->bind_param("ii", $submission_id, $_SESSION['teacher_id']);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

if (!$data) {
    die("Invalid submission or access denied.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $marks = trim($_POST['marks'] ?? '');
    $remark = trim($_POST['teacher_remark'] ?? '');

    if ($marks === '' || !is_numeric($marks)) {
        $msg = "Enter valid marks.";
        $msgType = "bad";
    } else {
        $m = (int)$marks;

        if ($m < 0 || $m > 100) {
            $msg = "Marks must be between 0 and 100.";
            $msgType = "bad";
        } else {
            $up = $conn->prepare("UPDATE submissions SET marks=?, teacher_remark=? WHERE id=?");
            $up->bind_param("isi", $m, $remark, $submission_id);
            $up->execute();

            $msg = "Marks saved successfully.";
            $msgType = "ok";

            $stmt = $conn->prepare("SELECT s.id, s.marks, s.teacher_remark, s.file_name,
                                           a.title, a.due_date,
                                           st.full_name AS student_name, st.prn
                                    FROM submissions s
                                    JOIN assignments a ON s.assignment_id = a.id
                                    JOIN students st ON s.student_id = st.id
                                    JOIN assignments ax ON s.assignment_id = ax.id
                                    WHERE s.id = ? AND ax.teacher_id = ?
                                    LIMIT 1");
            $stmt->bind_param("ii", $submission_id, $_SESSION['teacher_id']);
            $stmt->execute();
            $data = $stmt->get_result()->fetch_assoc();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Give Marks</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
    body{background:#eef8f5}
    .box{max-width:650px;margin:50px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 15px 40px rgba(0,0,0,.08)}
    h2{color:#11998e;margin-bottom:14px}
    p{margin:8px 0;color:#333}
    input,textarea{
      width:100%;
      padding:12px;
      margin:8px 0;
      border:1px solid #ccc;
      border-radius:10px;
    }
    textarea{height:110px;resize:vertical}
    button,.btn{
      background:#11998e;
      color:#fff;
      border:none;
      padding:12px 18px;
      border-radius:10px;
      font-weight:bold;
      text-decoration:none;
      display:inline-block;
    }
    .msg{padding:10px;border-radius:10px;margin:12px 0;background:#e8fff0;color:#116530}
    .bad{background:#ffe5e5;color:#b00020}
    .file-link{display:inline-block;margin-top:4px}
  </style>
</head>
<body>
  <div class="box">
    <h2>Give Marks</h2>

    <p><strong>Student:</strong> <?php echo htmlspecialchars($data['student_name']); ?></p>
    <p><strong>PRN:</strong> <?php echo htmlspecialchars($data['prn']); ?></p>
    <p><strong>Assignment:</strong> <?php echo htmlspecialchars($data['title']); ?></p>
    <p><strong>Due Date:</strong> <?php echo htmlspecialchars($data['due_date']); ?></p>
    <p>
      <strong>Submitted File:</strong><br>
      <a class="file-link" href="uploads/<?php echo rawurlencode($data['file_name']); ?>" target="_blank">
        <?php echo htmlspecialchars($data['file_name']); ?>
      </a>
    </p>

    <?php if($msg !== ""): ?>
      <div class="msg <?php echo $msgType === 'bad' ? 'bad' : ''; ?>">
        <?php echo htmlspecialchars($msg); ?>
      </div>
    <?php endif; ?>

    <form method="POST">
      <input type="number" name="marks" min="0" max="100" placeholder="Enter marks out of 100" value="<?php echo htmlspecialchars((string)($data['marks'] ?? '')); ?>" required>
      <textarea name="teacher_remark" placeholder="Enter teacher remark"><?php echo htmlspecialchars($data['teacher_remark'] ?? ''); ?></textarea>
      <button type="submit">Save Marks</button>
    </form>

    <br>
    <a class="btn" href="view_submissions.php">Back</a>
  </div>
</body>
</html>