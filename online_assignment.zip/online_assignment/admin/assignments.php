<?php
session_start();
require_once("../config/db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: ../auth/admin_login.php");
    exit();
}

// Fetch assignments
$result = $conn->query("SELECT * FROM assignments");
?>

<!DOCTYPE html>
<html>
<head>
<title>Assignments</title>

<style>
body{
    margin:0;
    font-family:Segoe UI;
    background:#f4f6f9;
}

/* Sidebar */
.sidebar{
    width:230px;
    background:#111827;
    color:white;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    padding:20px;
}

.sidebar a{
    display:block;
    color:#ccc;
    text-decoration:none;
    margin:10px 0;
    padding:10px;
    border-radius:6px;
}
.sidebar a:hover{
    background:#374151;
    color:white;
}

/* Main */
.main{
    margin-left:250px;
    padding:30px;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}
th,td{
    padding:12px;
    text-align:left;
}
th{
    background:#111;
    color:white;
}
tr:nth-child(even){
    background:#f2f2f2;
}

/* Buttons */
.btn{
    padding:8px 12px;
    background:#111;
    color:white;
    text-decoration:none;
    border-radius:6px;
}
.btn:hover{
    background:#333;
}
</style>

</head>
<body>

<div class="sidebar">
<h2>Admin Panel</h2>
<a href="dashboard.php">Dashboard</a>
<a href="manage_students.php">Manage Students</a>
<a href="manage_teachers.php">Manage Teachers</a>
<a href="assignments.php">Assignments</a>
</div>

<div class="main">

<h2>Assignments</h2>

<table>
<tr>
<th>ID</th>
<th>Title</th>
<th>Subject</th>
<th>Due Date</th>
<th>Action</th>
</tr>

<?php if($result->num_rows > 0): ?>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo htmlspecialchars($row['id']); ?></td>
        <td><?php echo htmlspecialchars($row['title']); ?></td>
        <td><?php echo htmlspecialchars($row['subject']); ?></td>
        <td><?php echo htmlspecialchars($row['due_date']); ?></td>
        <td>
            <a class="btn" href="delete_assignment.php?id=<?php echo $row['id']; ?>" 
               onclick="return confirm('Are you sure you want to delete this assignment?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr>
        <td colspan="5" style="text-align:center;">No assignments found.</td>
    </tr>
<?php endif; ?>

</table>

<br>
<a class="btn" href="dashboard.php">Back</a>

</div>

</body>
</html>