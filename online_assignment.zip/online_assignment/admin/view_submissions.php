<?php
session_start();
require_once("../config/db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: ../auth/admin_login.php");
    exit();
}

// 🔥 JOIN query
$result = $conn->query("
SELECT 
    submissions.*, 
    students.full_name AS student_name,
    students.prn,
    teachers.full_name AS teacher_name,
    assignments.title 
FROM submissions
JOIN students ON submissions.student_id = students.id
JOIN assignments ON submissions.assignment_id = assignments.id
LEFT JOIN teachers ON assignments.teacher_id = teachers.id
ORDER BY submissions.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>All Submissions</title>

<style>
body{margin:0;font-family:Segoe UI;background:#f4f6f9}

.sidebar{
    width:230px;background:#111827;color:white;height:100vh;
    position:fixed;padding:20px;
}

.sidebar a{
    display:block;color:#ccc;text-decoration:none;
    margin:10px 0;padding:10px;border-radius:6px;
}
.sidebar a:hover{background:#374151;color:white}

.main{margin-left:250px;padding:30px}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

th,td{padding:12px;text-align:left}
th{background:#111;color:white}
tr:nth-child(even){background:#f2f2f2}

.btn{
    padding:6px 10px;
    background:#111;
    color:white;
    text-decoration:none;
    border-radius:6px;
}
</style>
</head>

<body>

<div class="sidebar">
<h2>Admin Panel</h2>
<a href="dashboard.php">Dashboard</a>
<a href="manage_students.php">Students</a>
<a href="manage_teachers.php">Teachers</a>
<a href="view_submissions.php">Submissions</a>
</div>

<div class="main">

<h2>Assignment Submissions</h2>

<table>
<tr>
<th>Student Name</th>
<th>PRN</th>
<th>Assignment</th>
<th>Teacher</th>
<th>File</th>
<th>Date</th>
</tr>

<?php while($row = $result->fetch_assoc()){ ?>
<tr>
<td><?php echo $row['student_name']; ?></td>
<td><?php echo $row['prn']; ?></td>
<td><?php echo $row['title']; ?></td>
<td><?php echo $row['teacher_name'] ?? 'N/A'; ?></td>

<td>
<a class="btn" href="../uploads/<?php echo $row['file']; ?>" target="_blank">
View
</a>
</td>

<td><?php echo $row['submitted_at']; ?></td>
</tr>
<?php } ?>

</table>

</div>

</body>
</html>