<?php
session_start();
require_once("../config/db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: ../auth/admin_login.php");
    exit();
}

// Delete teacher if requested
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM teachers WHERE id=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();
    header("Location: manage_teachers.php");
    exit();
}

$result = $conn->query("SELECT * FROM teachers");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Teachers</title>

<style>
body{margin:0;font-family:Segoe UI;background:#f4f6f9}
.sidebar{
    width:230px;background:#111827;color:white;height:100vh;
    position:fixed;padding:20px;
}
.sidebar a{display:block;color:#ccc;text-decoration:none;margin:10px 0;padding:8px;border-radius:6px}
.sidebar a:hover{background:#374151;color:white}

.main{margin-left:250px;padding:30px}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:10px;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

th,td{padding:12px;text-align:left}
th{background:#111;color:white}
tr:nth-child(even){background:#f2f2f2}

.btn{
    display:inline-block;
    margin-top:10px;
    padding:6px 10px;
    background:#111;
    color:white;
    text-decoration:none;
    border-radius:6px;
}
.btn:hover{background:#333}
</style>

</head>
<body>

<div class="sidebar">
<h2>Admin Panel</h2>
<a href="dashboard.php">Dashboard</a>
<a href="manage_students.php">Manage Students</a>
<a href="manage_teachers.php">Manage Teachers</a>
<a href="assignments.php">Assignments</a>
</div>

<div class="main">

<h2>Manage Teachers</h2>

<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>PRN</th>
<th>Subject</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()){ ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['full_name']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo !empty($row['prn']) ? $row['prn'] : 'N/A'; ?></td>
<td><?php echo !empty($row['subject']) ? $row['subject'] : 'N/A'; ?></td>
<td>
    <a class="btn" href="manage_teachers.php?delete=<?php echo $row['id']; ?>" 
       onclick="return confirm('Are you sure you want to delete this teacher?')">Delete</a>
</td>
</tr>
<?php } ?>

</table>

<a class="btn" href="dashboard.php">Back</a>

</div>

</body>
</html>