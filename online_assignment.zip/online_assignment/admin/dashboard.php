<?php
session_start();
require_once("../config/db.php");

// 🔒 सुरक्षा
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../auth/admin_login.php");
    exit();
}

// Counts
$studentCount = $conn->query("SELECT COUNT(*) AS c FROM students")->fetch_assoc()['c'] ?? 0;
$teacherCount = $conn->query("SELECT COUNT(*) AS c FROM teachers")->fetch_assoc()['c'] ?? 0;
$assignmentCount = $conn->query("SELECT COUNT(*) AS c FROM assignments")->fetch_assoc()['c'] ?? 0;
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif}

body{
    display:flex;
    background:#f4f6f9;
}

/* Sidebar */
.sidebar{
    width:230px;
    background:#111827;
    color:white;
    height:100vh;
    padding:20px;
    position:fixed;
}

.sidebar h2{
    margin-bottom:30px;
    font-size:22px;
}

.sidebar a{
    display:block;
    color:#d1d5db;
    text-decoration:none;
    margin:12px 0;
    padding:10px;
    border-radius:8px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#374151;
    color:white;
}

/* Main */
.main{
    margin-left:230px;
    width:100%;
}

/* Topbar */
.topbar{
    background:white;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    box-shadow:0 5px 15px rgba(0,0,0,0.05);
}

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    padding:20px;
}

.card{
    background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
}

.card h3{
    margin-bottom:10px;
    color:#555;
}

.card p{
    font-size:30px;
    font-weight:bold;
    color:#111;
}

.logout{
    text-decoration:none;
    color:red;
}
</style>

</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="manage_students.php">Manage Students</a>
<a href="manage_teachers.php">Manage Teachers</a>
<a href="assignments.php">Assignments</a>
    <a href="../index.php">Home</a>
    <a href="../auth/admin_login.php">Logout</a>

</div>

<!-- Main -->
<div class="main">

    <!-- Topbar -->
    <div class="topbar">
        <div><strong>Dashboard</strong></div>
        <div>
            Welcome, <?php echo $_SESSION['admin_name']; ?> |
            <a class="logout" href="../logout.php">Logout</a>
        </div>
    </div>

    <!-- Cards -->
    <div class="cards">

        <div class="card">
            <h3>Total Students</h3>
            <p><?php echo $studentCount; ?></p>
        </div>

        <div class="card">
            <h3>Total Teachers</h3>
            <p><?php echo $teacherCount; ?></p>
        </div>

        <div class="card">
            <h3>Total Assignments</h3>
            <p><?php echo $assignmentCount; ?></p>
        </div>

    </div>

</div>

</body>
</html>