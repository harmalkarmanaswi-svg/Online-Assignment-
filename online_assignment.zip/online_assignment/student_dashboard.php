
<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'] ?? 'Student';
$student_prn = $_SESSION['student_prn'] ?? '';

$totalAssignments = $conn->query("SELECT COUNT(*) AS c FROM assignments")->fetch_assoc()['c'];

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM submissions WHERE student_id=?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$submittedCount = $stmt->get_result()->fetch_assoc()['c'];

$stmt2 = $conn->prepare("SELECT COUNT(*) AS c FROM submissions WHERE student_id=? AND marks IS NOT NULL");
$stmt2->bind_param("i", $student_id);
$stmt2->execute();
$gradedCount = $stmt2->get_result()->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Dashboard</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
    body{background:#f4f7fb;margin:0}
    .topbar{
      background:#1e3c72;
      color:#fff;
      padding:18px 25px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      flex-wrap:wrap;
      gap:10px;
    }
    .topbar h1{font-size:24px}
    .user-box{
      background:rgba(255,255,255,.12);
      padding:10px 14px;
      border-radius:12px;
      font-size:14px;
      line-height:1.6;
    }
    .wrap{padding:25px;max-width:1100px;margin:auto}
    .stats{
      display:grid;
      grid-template-columns:repeat(3,1fr);
      gap:20px;
      margin-bottom:25px;
    }
    .cards{
      display:grid;
      grid-template-columns:repeat(4,1fr);
      gap:20px;
    }
    .stat,.card{
      background:#fff;
      padding:25px;
      border-radius:18px;
      box-shadow:0 10px 30px rgba(0,0,0,.08);
    }
    .stat h3,.card h3{margin-bottom:10px;color:#1e3c72}
    .stat p{font-size:30px;font-weight:bold;color:#111}
    .card p{color:#555;line-height:1.6;margin-bottom:16px}
    .btn{
      display:inline-block;
      text-decoration:none;
      background:#1e3c72;
      color:#fff;
      padding:12px 18px;
      border-radius:10px;
      font-weight:bold;
    }
    .btn.logout{background:#c62828}
    @media(max-width:900px){
      .stats,.cards{grid-template-columns:1fr}
      .topbar{flex-direction:column;align-items:flex-start}
    }
  </style>
</head>
<body>
  <div class="topbar">
    <h1>Student Dashboard</h1>
    <div class="user-box">
      <div><strong>Name:</strong> <?php echo htmlspecialchars($student_name); ?></div>
      <div><strong>PRN:</strong> <?php echo htmlspecialchars($student_prn); ?></div>
    </div>
  </div>

  <div class="wrap">
    <div class="stats">
      <div class="stat">
        <h3>Total Assignments</h3>
        <p><?php echo (int)$totalAssignments; ?></p>
      </div>
      <div class="stat">
        <h3>My Submissions</h3>
        <p><?php echo (int)$submittedCount; ?></p>
      </div>
      <div class="stat">
        <h3>Checked / Graded</h3>
        <p><?php echo (int)$gradedCount; ?></p>
      </div>
    </div>

    <div class="cards">
      <div class="card">
        <h3>Available Assignments</h3>
        <p>View all assignments with due dates.</p>
        <a class="btn" href="student_assignments.php">Open</a>
      </div>

      <div class="card">
        <h3>Submit Assignment</h3>
        <p>Upload your work for available assignments.</p>
        <a class="btn" href="student_assignments.php">Submit</a>
      </div>

      <div class="card">
        <h3>My Results</h3>
        <p>Check marks and teacher remarks.</p>
        <a class="btn" href="student_results.php">View</a>
      </div>

      <div class="card">
        <h3>Logout</h3>
        <p>Sign out safely from your account.</p>
        <a class="btn logout" href="logout.php">Logout</a>
      </div>
    </div>
  </div>
</body>
</html>