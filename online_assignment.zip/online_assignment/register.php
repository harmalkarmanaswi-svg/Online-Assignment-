<?php
require_once(__DIR__ . "/config/db.php");

$msg = "";

function is_strong_password($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&^#().,_+\-]).{8,}$/', $password);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $student_prn = trim($_POST['student_prn'] ?? '');
    $teacher_id = trim($_POST['teacher_id'] ?? '');

    if ($role === "" || $full_name === "" || $email === "" || $password === "") {
        $msg = "Please fill all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Please enter a valid email address.";
    } elseif (!is_strong_password($password)) {
        $msg = "Password must be at least 8 characters and include uppercase, lowercase, number, and special character.";
    } else {
        if ($role === "student") {
            if (!preg_match('/^\d{16}$/', $student_prn)) {
                $msg = "Student PRN must be exactly 16 digits.";
            } else {
                $check = $conn->prepare("SELECT id FROM students WHERE prn = ? OR email = ? LIMIT 1");
                $check->bind_param("ss", $student_prn, $email);
                $check->execute();
                $check->store_result();

                if ($check->num_rows > 0) {
                    $msg = "Student PRN or email already exists.";
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO students (full_name, prn, email, password) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssss", $full_name, $student_prn, $email, $hash);
                    $stmt->execute();

                    header("Location: login.php?registered=1");
                    exit();
                }
            }
        } elseif ($role === "teacher") {
            if (!preg_match('/^\d{8}$/', $teacher_id)) {
                $msg = "Teacher ID must be exactly 8 digits.";
            } else {
                $check = $conn->prepare("SELECT id FROM teachers WHERE teacher_id = ? OR email = ? LIMIT 1");
                $check->bind_param("ss", $teacher_id, $email);
                $check->execute();
                $check->store_result();

                if ($check->num_rows > 0) {
                    $msg = "Teacher ID or email already exists.";
                } else {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("INSERT INTO teachers (full_name, teacher_id, email, password) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssss", $full_name, $teacher_id, $email, $hash);
                    $stmt->execute();

                    header("Location: login.php?registered=1");
                    exit();
                }
            }
        } else {
            $msg = "Please select a valid role.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register</title>

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:Arial, sans-serif;
}

body{
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
  padding:20px;
}

.card{
  width:100%;
  max-width:450px;
  background:#ffffff;
  padding:30px;
  border-radius:18px;
  box-shadow:0 20px 45px rgba(0,0,0,0.18);
}

h2{
  margin-bottom:18px;
  color:#111;
}

.field{
  margin-bottom:15px;
}

input, select{
  width:100%;
  padding:14px 12px;
  border:1px solid #ccc;
  border-radius:10px;
  font-size:15px;
  outline:none;
}

input:focus, select:focus{
  border-color:#203a43;
  box-shadow:0 0 0 3px rgba(32,58,67,0.10);
}

.password-wrap{
  position:relative;
  width:100%;
}

.password-wrap input{
  width:100%;
  padding:14px 90px 14px 12px;
  border:1px solid #ccc;
  border-radius:10px;
  font-size:15px;
  outline:none;
}

.password-wrap input:focus{
  border-color:#203a43;
  box-shadow:0 0 0 3px rgba(32,58,67,0.10);
}

.toggle-btn{
  position:absolute;
  right:8px;
  top:50%;
  transform:translateY(-50%);
  border:none;
  background:#203a43;
  color:#fff;
  padding:8px 12px;
  border-radius:8px;
  cursor:pointer;
  font-size:12px;
  font-weight:bold;
}

.toggle-btn:hover{
  background:#162a31;
}

.btn{
  width:100%;
  padding:13px;
  background:#203a43;
  color:white;
  border:none;
  border-radius:10px;
  font-size:15px;
  font-weight:bold;
  cursor:pointer;
}

.btn:hover{
  background:#162a31;
}

.msg{
  padding:10px;
  margin-bottom:12px;
  border-radius:10px;
  font-size:14px;
}

.error{
  background:#ffe5e5;
  color:#b00020;
}

.bottom{
  margin-top:16px;
  text-align:center;
  font-size:14px;
}

.bottom a{
  color:#203a43;
  text-decoration:none;
  font-weight:bold;
}

.hint{
  font-size:12px;
  color:#666;
  margin-top:6px;
  line-height:1.5;
}

.hidden{
  display:none;
}
</style>
</head>
<body>

<div class="card">
  <h2>Register</h2>

  <?php if($msg != ""): ?>
    <div class="msg error"><?php echo htmlspecialchars($msg); ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="field">
      <select name="role" id="roleSelect" required>
        <option value="">Select Role</option>
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
      </select>
    </div>

    <div class="field">
      <input type="text" name="full_name" placeholder="Full Name" required>
    </div>

    <div class="field hidden" id="studentPrnBox">
      <input type="text" name="student_prn" id="student_prn" maxlength="16" placeholder="Enter 16-digit PRN">
    </div>

    <div class="field hidden" id="teacherIdBox">
      <input type="text" name="teacher_id" id="teacher_id" maxlength="8" placeholder="Enter 8-digit Teacher ID">
    </div>

    <div class="field">
      <input type="email" name="email" placeholder="Enter valid email" required>
    </div>

    <div class="field">
      <div class="password-wrap">
        <input type="password" name="password" id="password" placeholder="Create strong password" required>
        <button type="button" class="toggle-btn" onclick="togglePassword()" id="toggleBtn">Show</button>
      </div>
      <div class="hint">
        Password must be at least 8 characters and include uppercase, lowercase, number, and special character.
      </div>
    </div>

    <button type="submit" class="btn">Create Account</button>
  </form>

  <div class="bottom">
    Already have an account? <a href="login.php">Login</a>
  </div>
</div>

<script>
function togglePassword() {
  var x = document.getElementById("password");
  var btn = document.getElementById("toggleBtn");

  if (x.type === "password") {
    x.type = "text";
    btn.textContent = "Hide";
  } else {
    x.type = "password";
    btn.textContent = "Show";
  }
}

const roleSelect = document.getElementById('roleSelect');
const studentPrnBox = document.getElementById('studentPrnBox');
const teacherIdBox = document.getElementById('teacherIdBox');
const studentPrn = document.getElementById('student_prn');
const teacherId = document.getElementById('teacher_id');

function updateRoleFields() {
  const role = roleSelect.value;

  studentPrnBox.classList.add('hidden');
  teacherIdBox.classList.add('hidden');
  studentPrn.required = false;
  teacherId.required = false;

  if (role === 'student') {
    studentPrnBox.classList.remove('hidden');
    studentPrn.required = true;
  } else if (role === 'teacher') {
    teacherIdBox.classList.remove('hidden');
    teacherId.required = true;
  }
}

roleSelect.addEventListener('change', updateRoleFields);
updateRoleFields();
</script>

</body>
</html>