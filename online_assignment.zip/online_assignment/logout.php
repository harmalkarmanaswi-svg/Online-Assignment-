<?php
session_start();
require_once("config/db.php");

if (isset($_SESSION['student_id'])) {
    $student_id = $_SESSION['student_id'];

    // Clear session ID from DB
    $stmt = $conn->prepare("UPDATE students SET session_id=NULL WHERE id=?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
}

// Destroy session
$_SESSION = [];
session_destroy();

header("Location: index.php");
exit();
?>