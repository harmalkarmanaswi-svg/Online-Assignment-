require_once("../config/db.php");
require_once("../config/session.php");
checkStudent();

$student_id = $_SESSION['student_id'];
$assignment_id = $_POST['assignment_id'];

// Check already submitted
$check = $conn->query("SELECT * FROM submissions WHERE student_id='$student_id' AND assignment_id='$assignment_id'");

if ($check->num_rows > 0) {
    header("Location: status.php");
    exit();
}

// Upload logic
$file = $_FILES['file']['name'];
$tmp = $_FILES['file']['tmp_name'];
$path = "../uploads/" . time() . "_" . $file;

move_uploaded_file($tmp, $path);

// Insert
$conn->query("INSERT INTO submissions (student_id, assignment_id, file, status)
VALUES ('$student_id','$assignment_id','$path','pending')");

header("Location: status.php");