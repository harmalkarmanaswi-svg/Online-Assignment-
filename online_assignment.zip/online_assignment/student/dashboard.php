<?php
require_once("../config/session.php");
checkStudent();

if(!isset($_SESSION['student_id'])){
    header("Location: ../auth/student_login.php");
    exit();
}
$check = $conn->query("SELECT * FROM submissions WHERE student_id='$student_id' AND assignment_id='$assignment_id'");

if ($check->num_rows > 0) {
    echo "<button disabled>Already Submitted</button>";
} else {
    echo "<button>Submit</button>";
}
?>

<h2>Student Dashboard</h2>

Welcome <?php echo $_SESSION['student_name']; ?>

<br><br>

<a href="../index.php">Home</a>
<div class="assignment-card">
<h3><?= $row['title'] ?></h3>
<p><?= $row['description'] ?></p>
<button class="btn-submit">Submit</button>
</div>