require_once("../config/db.php");
require_once("../config/session.php");
checkStudent();

$id = $_SESSION['student_id'];

$res = $conn->query("
SELECT a.title, s.status, s.file
FROM submissions s
JOIN assignments a ON a.id = s.assignment_id
WHERE s.student_id='$id'
");
<h2>Your Submissions</h2>

<table>
<tr>
<th>Assignment</th>
<th>Status</th>
<th>File</th>
</tr>

<?php while($row = $res->fetch_assoc()): ?>
<tr>
<td><?= $row['title'] ?></td>
<td><?= $row['status'] ?></td>
<td><a href="<?= $row['file'] ?>">View</a></td>
</tr>
<?php endwhile; ?>
</table>