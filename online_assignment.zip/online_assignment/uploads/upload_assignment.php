<?php

$msg="";

if(isset($_POST['upload']))
{

$filename = $_FILES['file']['name'];

$tempname = $_FILES['file']['tmp_name'];

$folder = "uploads/".$filename;

if(move_uploaded_file($tempname,$folder))
{
$msg="File Uploaded Successfully";
}
else
{
$msg="Upload Failed";
}

}

?>

<!DOCTYPE html>
<html>
<head>

<title>Upload Assignment</title>

<style>

body{
font-family:Arial;
background:#f5f7fb;
}

.box{
width:400px;
margin:100px auto;
background:white;
padding:20px;
text-align:center;
box-shadow:0 0 10px #ccc;
border-radius:10px;
}

button{
padding:10px;
background:#1e3c72;
color:white;
border:none;
}

</style>

</head>

<body>

<div class="box">

<h2>Upload Assignment</h2>

<form method="POST" enctype="multipart/form-data">

<input type="file" name="file" required>

<br><br>

<button name="upload">Upload</button>

</form>

<p><?php echo $msg; ?></p>

<br>

<a href="student_dashboard.php">Back</a>

</div>

</body>
</html>