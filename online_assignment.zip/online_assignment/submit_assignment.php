<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
require_once(__DIR__ . "/config/db.php");

$assignment_id = (int)($_GET['assignment_id'] ?? 0);
$student_id = $_SESSION['student_id'];
$msg = "";
$msgType = "ok";

$stmt = $conn->prepare("SELECT id, title, due_date FROM assignments WHERE id=? LIMIT 1");
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$assignment = $stmt->get_result()->fetch_assoc();

if (!$assignment) {
    die("Invalid assignment.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== 0) {
        $msg = "Please choose a file.";
        $msgType = "bad";
    } else {
        $allowed = ['pdf','doc','docx','jpg','jpeg','png'];
        $original = $_FILES['file']['name'];
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $size = $_FILES['file']['size'];

        if (!in_array($ext, $allowed, true)) {
            $msg = "Only PDF, DOC, DOCX, JPG, JPEG, PNG allowed.";
            $msgType = "bad";
        } elseif ($size > 5 * 1024 * 1024) {
            $msg = "File size must be less than 5 MB.";
            $msgType = "bad";
        } else {
            $filename = time() . "_" . preg_replace('/[^A-Za-z0-9_\.-]/', '_', basename($original));
            $tmp = $_FILES['file']['tmp_name'];
            $target = __DIR__ . "/uploads/" . $filename;

            $check = $conn->prepare("SELECT id FROM submissions WHERE assignment_id=? AND student_id=? LIMIT 1");
            $check->bind_param("ii", $assignment_id, $student_id);
            $check->execute();
            $check->store_result();

            if ($check->num_rows > 0) {
                $msg = "You already submitted this assignment.";
                $msgType = "bad";
            } else {
                if (move_uploaded_file($tmp, $target)) {
                    $ins = $conn->prepare("INSERT INTO submissions (assignment_id, student_id, file_name) VALUES (?, ?, ?)");
                    $ins->bind_param("iis", $assignment_id, $student_id, $filename);
                    $ins->execute();
                    $msg = "Assignment submitted successfully.";
                } else {
                    $msg = "File upload failed.";
                    $msgType = "bad";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Submit Assignment</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}
    body{background:#f4f7fb}
    .box{max-width:550px;margin:50px auto;background:#fff;padding:30px;border-radius:20px;box-shadow:0 15px 40px rgba(0,0,0,.08)}
    h2{color:#1e3c72;margin-bottom:10px}
    p{margin:8px 0}
    input[type=file]{margin:15px 0}
    button,.btn{background:#1e3c72;color:#fff;border:none;padding:12px 18px;border-radius:10px;font-weight:bold;text-decoration:none;display:inline-block}
    .msg{padding:10px;border-radius:10px;margin-bottom:10px;background:#e8fff0;color:#116530}
    .bad{background:#ffe5e5;color:#b00020}
  </style>
</head>
<body>
  <div class="box">
    <h2>Submit Assignment</h2>
    <p><strong>Title:</strong> <?php echo htmlspecialchars($assignment['title']); ?></p>
    <p><strong>Due Date:</strong> <?php echo htmlspecialchars($assignment['due_date']); ?></p>

    <?php if($msg !== ""): ?>
      <div class="msg <?php echo $msgType === 'bad' ? 'bad' : ''; ?>">
        <?php echo htmlspecialchars($msg); ?>
      </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <input type="file" name="file" required>
      <br>
      <button type="submit">Upload Submission</button>
    </form>

    <p>Allowed: PDF, DOC, DOCX, JPG, JPEG, PNG | Max 5 MB</p>

    <br>
    <a class="btn" href="student_assignments.php">Back</a>
  </div>
</body>
</html>